# ViraGen - Viral Video Content Generator

## Overview

ViraGen is a full-stack web application designed to help users create viral video content by analyzing successful YouTube channels and generating optimized scripts, images, and audio. The platform uses AI-powered analysis to identify viral patterns and automate content creation workflows.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side is built with React and TypeScript using a modern component-based architecture:
- **Framework**: React 18 with TypeScript for type safety and development efficiency
- **Styling**: Tailwind CSS with a custom design system using CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible interfaces
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and API caching
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
The server follows a RESTful API design with Express.js:
- **Runtime**: Node.js with ES modules
- **Framework**: Express.js for HTTP server and middleware handling
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage Pattern**: Repository pattern with both in-memory and database storage implementations
- **API Design**: RESTful endpoints with JSON responses and proper error handling

### Database Schema
The application uses a relational database structure with four main entities:
- **Users**: Authentication and user management
- **Projects**: Main workflow containers linking users to their video creation projects
- **Video Analysis**: Stores analysis data for viral videos including metrics and AI-generated insights
- **Generated Content**: Manages AI-generated assets (titles, scripts, images, audio) with file path references

### Content Generation Pipeline
The system implements a multi-step workflow for viral video creation:
1. **Channel Analysis**: Fetches and analyzes viral videos from YouTube channels
2. **Pattern Recognition**: Uses AI to identify successful content patterns and structures
3. **Content Generation**: Creates titles, scripts, and visual assets based on identified patterns
4. **Media Production**: Generates audio using text-to-speech and assembles final video content

### AI Integration Architecture
Multiple AI services are integrated for content analysis and generation:
- **Google Gemini AI**: Video content analysis, title generation, script creation, and image generation
- **Google Cloud Text-to-Speech**: Voice synthesis with configurable voice types and speeds
- **YouTube Data API**: Channel and video metadata retrieval for analysis

## External Dependencies

### Core Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting for scalable data storage
- **Google Cloud Platform**: Authentication and API access for AI services

### AI and Content Services
- **Google Gemini AI (@google/genai)**: Advanced language model for content analysis and generation
- **Google Cloud Text-to-Speech**: High-quality voice synthesis with Portuguese language support
- **YouTube Data API**: Access to public video and channel data for viral pattern analysis

### Development and Runtime
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **TanStack Query**: Server state management and API caching
- **Radix UI**: Accessible UI primitive components
- **Tailwind CSS**: Utility-first styling framework
- **Vite**: Modern build tool with hot module replacement

### Authentication and Session Management
- **connect-pg-simple**: PostgreSQL session store for user authentication
- **Express Sessions**: Session-based authentication middleware

The system is designed to be modular and scalable, with clear separation between data access, business logic, and presentation layers. The AI integration allows for sophisticated content analysis while maintaining flexibility for different content creation workflows.